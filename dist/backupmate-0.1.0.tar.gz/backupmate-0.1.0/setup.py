# setup.py

from setuptools import setup
import setuptools

setup()
